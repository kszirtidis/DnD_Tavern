Citation for Update javascript functions:

Date: 2/29/2024 
Adapted from code provided by Prof. Safonte and Dr. Curry for students at Oregon State University. Function
was adapted and changed according to the needs of our database. Some comments were modified or removed.
Source: https://github.com/osu-cs340-ecampus/nodejs-starter-app


Citation for Delete javascript functions:

Date: 2/29/2024 
Adapted from code provided by Prof. Safonte and Dr. Curry for students at Oregon State University. Function
was adapted and changed according to the needs of our database.
Source: https://github.com/osu-cs340-ecampus/nodejs-starter-app


Citation for handlebars pages:

Date: 2/29/2024 
Adapted from code provided by Prof. Safonte and Dr. Curry for students at Oregon State University. Tables
were adapted and changed according to the needs of our database. Some comments were removed for clarity.
Source: https://github.com/osu-cs340-ecampus/nodejs-starter-app


Citation for App javascript function:

Date: 2/29/2024 
Adapted from code provided by Prof. Safonte and Dr. Curry for students at Oregon State University. Functions
were adapted and changed according to the needs of our database. Comments were added, removed, or changed 
depending on the needs of our database.
Source: https://github.com/osu-cs340-ecampus/nodejs-starter-app


Citation for db-connector javascript function:

Date: 2/29/2024 
Adapted from code provided by Prof. Safonte and Dr. Curry for students at Oregon State University.
Source: https://github.com/osu-cs340-ecampus/nodejs-starter-app